package com.example.a0529map


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import nctu.fintech.appmate.Table
import nctu.fintech.appmate.Tuple
import java.io.IOException
import java.util.*

class chatroom : AppCompatActivity() {
    var b1: Button? = null
    var mTable: Table? = null
    var et1: EditText? = null
    var et2: EditText? = null
    var tv1: TextView? = null
    var s1: String? = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatroom)
        mTable = Table("http://140.113.72.35:8000/api", "class8", "admin", "admin123")
        b1 = findViewById(R.id.button)
        b1?.setOnClickListener(b1cl)
        et1 = findViewById(R.id.editText)
        et2 = findViewById(R.id.editText2)
        tv1 = findViewById(R.id.textView)
        val timer01 = Timer()
        timer01.schedule(task, 0, 10000)

    }

    private val b1cl =
        View.OnClickListener {
            Toast.makeText(this, "5566", Toast.LENGTH_LONG).show()
            val t1 = Thread(r1)
            t1.start()
        }
    private val r1 = Runnable {
        val tuple_add = Tuple()
        val groupname: String = et2?.getText().toString()
        val word2send: String = et1?.getText().toString()
        tuple_add.put("text1", word2send)
        tuple_add.put("text2", groupname)
        try {
            mTable!!.add(tuple_add)
        } catch (e: IOException) {
            Log.e("Net", "Fail to put")
        }
    }
    val task: TimerTask = object : TimerTask() {
        override fun run() {
            val t2 = Thread(r2)
            t2.start()
        }
    }
    private val r2 = Runnable {
        try {
            var tuple_get = mTable!!.get()
            s1 = ""
            for (i in 0 until tuple_get.size) {
                var tempString: String? = tuple_get[i].get("text1")
                if (tempString != null && tempString != "") {
                    s1 = s1.toString() + tempString + "\n"
                }
            }
            val msg = Message()
            msg.what = 1
            mHandler.sendMessage(msg)
        } catch (e: IOException) {
            Log.e("Net", "Fail to get")
        }
    }
    private val mHandler = object : Handler() {
        override fun handleMessage(msg: Message?) {
            if (msg?.what == 1) {
                tv1?.setText(s1)
            }
            super.handleMessage(msg)
            et1?.getText()?.clear()
        }
    }
}