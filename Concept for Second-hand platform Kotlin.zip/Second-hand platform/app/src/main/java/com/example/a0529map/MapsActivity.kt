package com.example.a0529map

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_maps.*
import kotlinx.android.synthetic.main.secondpage.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private val MINIMUM_DISTANCE_CHANGE_FOR_UPDATES: Long = 1
    private val MINIMUM_TIME_BETWEEN_UPDATES: Long = 1000
    protected var locationManager: LocationManager? = null
    protected var retrieveLocationButton: Button? = null
    protected var locationPrint: TextView? = null
    public var LastLocation: Location?= null //
    var TotalLocation: Float= 0F //




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
//       super.onCreate(savedInstanceState)
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager?
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        locationManager?.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            MINIMUM_TIME_BETWEEN_UPDATES,
            MINIMUM_DISTANCE_CHANGE_FOR_UPDATES.toFloat(),
            MyLocationListener()
        )
        map_bt1.setOnClickListener {
            //Toast.makeText(this,"5566",Toast.LENGTH_LONG).show()
            var intentP4 = Intent(this, chatroom::class.java)
            startActivityForResult(intentP4, 4)
        }

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val IMF = LatLng(24.7875690, 121.0007787)
        //mMap.addMarker(MarkerOptions().position(taiwan).title("Marker in Taiwan"))
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(taiwan))
        mMap.addMarker(MarkerOptions().position(IMF).title("Marker in IMF"))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(IMF, 18F))
        val R1 = LatLng(24.7879000, 121.0000000)
        //mMap.addMarker(MarkerOptions().position(taiwan).title("Marker in Taiwan"))
        mMap.addMarker(MarkerOptions().position(R1).title("Marker in R1"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(R1))

        val R2 = LatLng(24.7871800, 121.0010000)
        //mMap.addMarker(MarkerOptions().position(taiwan).title("Marker in Taiwan"))
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(taiwan))
        mMap.addMarker(MarkerOptions().position(R2).title("Marker in R2"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(R2))
    }

    private inner class MyLocationListener : LocationListener {
        override fun onLocationChanged(location: Location) {
            val message = String.format(
                "New Location \n Longitude: %1\$s \n Latitude: %2\$s",
                location.longitude, location.latitude
            )
            mMap.addMarker(MarkerOptions().position(LatLng(location.latitude,location.latitude)))
            if(LastLocation == null) {
                LastLocation = location
            }
            TotalLocation += location.distanceTo(LastLocation)
            Toast.makeText(
                this@MapsActivity,
                TotalLocation.toString(),
                Toast.LENGTH_LONG
            ).show()
            LastLocation = location
        }

        override fun onProviderDisabled(provider: String?) {
            Toast.makeText(
                this@MapsActivity,
                "Provider disabled by the user. GPS turned off",
                Toast.LENGTH_LONG
            ).show()
        }

        override fun onProviderEnabled(provider: String?) {
            Toast.makeText(
                this@MapsActivity, "Provider enabled by the user. GPS turned on", Toast.LENGTH_LONG
            ).show()
        }

        override fun onStatusChanged(
            provider: String?, status: Int, extras: Bundle?
        ) {
            Toast.makeText(this@MapsActivity, "Provider status changed", Toast.LENGTH_LONG).show()
        }

    }
    @SuppressLint("MissingPermission")
    protected fun showCurrentLocation() {
        val location = locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        if (location != null) {
            val message = String.format(
                "Current Location \n Longitude: %1\$s \n Latitude: %2\$s",
                location.longitude, location.latitude
            )
            locationPrint!!.text = message
        } else
            Toast.makeText(this@MapsActivity, "null", Toast.LENGTH_LONG).show()
    }
}


