package com.example.a0529map

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.secondpage.*

class secondpage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.secondpage)

        sp_bt_map.setOnClickListener {
            //Toast.makeText(this,"5566",Toast.LENGTH_LONG).show()
            var intentP3 = Intent(this, MapsActivity::class.java)
            startActivityForResult(intentP3, 3)
        }


    }


}
