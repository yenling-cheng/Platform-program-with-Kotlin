package com.example.a0529map

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class firstpage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.firstpage)
        var b2: Button = findViewById(R.id.main_bt2)
        var b3: Button = findViewById(R.id.main_bt3)
        b2.setOnClickListener {
            //Toast.makeText(this,"5566",Toast.LENGTH_LONG).show()
            var intentP2 = Intent(this, secondpage::class.java)
            startActivityForResult(intentP2, 2)
        }
        b3.setOnClickListener {
            var intentP2 = Intent(this,secondpage::class.java )
            startActivityForResult(intentP2,2)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }
}
